package java_pro;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Combobox extends JComboBox<Object>{
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  // jdbc 드라이버 주소
	static String dbServerAddr = "jdbc:mysql://localhost:3306/mydb?useSSL=false&serverTimezone=Asia/Seoul";
	static String user = "root"; // �뿬�윭遺� 怨꾩젙 �씠由꾩쑝濡� �닔�젙
	static String pswd = "0000"; // �뿬�윭遺� 鍮꾨�踰덊샇濡� �닔�젙
	private JComboBox<String> jcm1;
	
	Vector<String> data = new Vector<String>();
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;

	
	Combobox(){
		try {
			// DB �뿰寃�
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(dbServerAddr, user, pswd);
			// SQL �떎�뻾
			stmt = conn.prepareStatement("select 이름 from product");
			rs = stmt.executeQuery();
			
			data.removeAllElements();
			selectname();
			jcm1 = new JComboBox(data);
			System.out.println(data);
			jcm1.setEditable(true);
			jcm1.setVisible(true);

		}
		catch (SQLException e) {
			System.err.println("SQLException");
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
	         System.out.println("Class Not Found Exection");
	         e.printStackTrace();
		}
		// 由ъ냼�뒪 諛섑솚
		finally {
			if (rs != null)		try { rs.close(); }		catch (Exception e) {}
			if (stmt != null)	try { stmt.close(); }	catch (Exception e) {}
			if (conn != null)	try { conn.close(); }	catch (Exception e) {}
		}		
	}
	public Vector<String> selectname(){ 
		   Vector<String> data = new Vector<String>(); 
		   stmt = conn.prepareStatement("select 이름 from product");
		   rs = stmt.executeQuery();
		   try{ 
		      while(rs.next()){   
		          data.add(rs.getString(1));  
		     } 
		    }catch(SQLException e){ 
		     e.printStackTrace(); 
		    }finally{ 
		     conn.close(); 
		 } 
		return data; 
	}
}
